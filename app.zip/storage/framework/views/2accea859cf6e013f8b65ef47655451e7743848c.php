<div class="tab-pane" id="tab2">
    <br/><br/>
    <div class="row">
        <div class="col-sm-6">
            <label class="text-default-light">Featured Image</label>
            <?php if(isset($product) && $product->image): ?>
                <input type="file" name="image" class="dropify" id="input-file-events"
                       data-default-file="<?php echo e(asset($product->image_path)); ?>"/>

            <?php else: ?>
                <input type="file" name="image" class="dropify"/>
            <?php endif; ?>
            <input type="hidden" name="removeimage" id="removeimage" value=""/>
            <span id="textarea1-error" class="text-danger"><?php echo e($errors->first('image')); ?></span>
        </div>
        <div class="col-sm-6">
            <label class="text-default-light">Banner Image(Optional)</label>
            <?php if(isset($product) && $product->banner_image): ?>
                <input type="file" name="banner_image" class="dropify" id="input-file-events"
                       data-default-file="<?php echo e(asset($product->banner_path)); ?>"/>

            <?php else: ?>
                <input type="file" name="banner_image" class="dropify"/>
            <?php endif; ?>
            <input type="hidden" name="removeimage" id="removeimage" value=""/>
        </div>
    </div>
    <div class="row" style="margin-top: 20px">
        <div class="col-sm-6">
            <label class="text-default-light">Image 1(Optional)</label>
            <?php if(isset($product) && $product->image1): ?>
                <input type="file" name="image1" class="dropify" id="input-file-events" data-default-file="<?php echo e(asset($product->image_path1)); ?>"/>
            <?php else: ?>
                <input type="file" name="image1" class="dropify"/>
            <?php endif; ?>
            <input type="hidden" name="removeimage" id="removeimage" value=""/>
        </div>
        <div class="col-sm-6">
            <label class="text-default-light">Image 2(Optional)</label>
            <?php if(isset($product) && $product->image2): ?>
                <input type="file" name="image2" class="dropify" id="input-file-events" data-default-file="<?php echo e(asset($product->image_path2)); ?>"/>
            <?php else: ?>
                <input type="file" name="image2" class="dropify"/>
            <?php endif; ?>
            <input type="hidden" name="removeimage" id="removeimage" value=""/>
        </div>

        <button type="submit" class="btn btn-success" style="margin-top: 30px;position: relative;left: 50%;transform: translateX(-50%)">Submit</button>
    </div>

</div>
<!--end #tab2 -->
<?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/product/partials/gallery-tab.blade.php ENDPATH**/ ?>