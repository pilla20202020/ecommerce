<tr>
    <td><?php echo e(++$key); ?></td>
    <td><img src="<?php echo e(asset($product->image_path)); ?>" class="img-circle width-1" alt="<?php echo e($product->title); ?>" width="50" height="50"></td>
    <td><?php echo e(Str::limit($product->title, 47)); ?></td>
    <td><?php echo e(Str::limit($product->category->title, 47)); ?></td>
    <td>Rs. <?php echo e(Str::limit($product->price, 47)); ?></td>



    <td class="text-center">
        <?php if($product->is_featured =='1'): ?>
            <span class="badge" style="background-color: #419645"><?php echo e($product->is_featured ? 'Yes' : 'No'); ?></span>
        <?php elseif($product->is_featured =='0'): ?>
            <span class="badge" style="background-color: #f44336"><?php echo e($product->is_featured ? 'Yes' : 'No'); ?></span>
        <?php endif; ?>
    </td>
    <td class="text-right">
        
        <a href="<?php echo e(route('product.edit', $product->slug)); ?>" class="btn btn-flat btn-primary btn-xs" title="edit">
            <i class="glyphicon glyphicon-edit"></i>
        </a>
        <a href="<?php echo e(route('product.destroy', $product->id)); ?>">
            <button type="button"
                class="btn btn-flat btn-danger btn-xs item-delete" title="delete">
                <i class="glyphicon glyphicon-trash"></i>
            </button>
        </a>
    </td>
</tr>

<?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/product/partials/table.blade.php ENDPATH**/ ?>