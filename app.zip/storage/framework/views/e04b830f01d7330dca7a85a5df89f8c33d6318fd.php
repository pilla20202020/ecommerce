<tr>
    <td><?php echo e(++$key); ?></td>
    <td><img src="<?php echo e(asset($subcategory->thumbnail_path)); ?>" class="img-circle width-1" alt="<?php echo e($subcategory->title); ?>" width="50" height="50"></td>
    <td><?php echo e(Str::limit($subcategory->title, 47)); ?></td>
    <td><?php echo e(Str::limit($subcategory->category->title, 47)); ?></td>

    <td class="text-center">
        <?php if($subcategory->is_published =='1'): ?>
            <span class="badge" style="background-color: #419645"><?php echo e($subcategory->is_published ? 'Yes' : 'No'); ?></span>
        <?php elseif($subcategory->is_published =='0'): ?>
            <span class="badge" style="background-color: #f44336"><?php echo e($subcategory->is_published ? 'Yes' : 'No'); ?></span>
        <?php endif; ?>    </td>
    <td class="text-right">
        <a href="<?php echo e(route('subcategory.edit', $subcategory->slug)); ?>" class="btn btn-flat btn-primary btn-xs" title="edit">
            <i class="glyphicon glyphicon-edit"></i>
        </a>
        <a href="<?php echo e(route('subcategory.destroy', $subcategory->id)); ?>">
            <button type="button"
                class="btn btn-flat btn-danger btn-xs item-delete" title="delete">
                <i class="glyphicon glyphicon-trash"></i>
            </button>
    </td>
</tr>

<?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/subcategory/partials/table.blade.php ENDPATH**/ ?>