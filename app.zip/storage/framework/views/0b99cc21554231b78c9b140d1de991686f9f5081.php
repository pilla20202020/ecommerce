<?php $__env->startSection('content'); ?>
     <!--slider area start-->
     <section class="slider_section slider_section_three">
       
            <div class="slider_area owl-carousel">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single_slider d-flex align-items-center" data-bgimg="<?php echo e(asset($slide->image_path)); ?>">
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="slider_content slider_c_three">
                                        <h1><?php echo e($slide->title); ?></h1>
                                        <p><?php echo e($slide->caption); ?></p>
                                        
                                    </div>
                                </div>
                            </div>
                        </div> 
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
       
     </section>
     <!--slider area end-->

      <!--brand newsletter area start-->
      <div class="brand_area brand_three">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="brand_container owl-carousel">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single_brand">
                                <a href="#"><img src="<?php echo e(asset($brand->image_path)); ?>" alt=""></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--brand area end-->

    <!--banner area start-->
    <div class="banner_area banner_three pt-70 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title title_style3">
                        <h3>Featured Category</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6">
                        <div class="single_banner">
                            <div class="banner_thumb">
                                <a href="<?php echo e(route('products',$category->slug)); ?>"><img src="<?php echo e(asset($category->image_path)); ?>" alt=""></a>
                                <div class="banner_text">
                                    <a href="<?php echo e(route('products',$category->slug)); ?>"><?php echo e($category->title); ?></a>
                                </div>
                            </div>
                        
                        </div>
                    </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
            </div>
        </div>
    </div>
    <!--banner area end-->

     <!--new product area start-->
     <section class="product_area product_three mt-70 mb-40">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title title_style3">
                        <h3>Our Products</h3>
                    </div>
                    <div class="product_tab_btn3">
                        <ul class="nav" role="tablist">
                            <li>
                                <a class="active" data-toggle="tab" href="#Nailpolish" role="tab" aria-controls="Nailpolish" aria-selected="true"> 
                                    Nailpolish
                                </a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#Eyes" role="tab" aria-controls="Eyes" aria-selected="false">
                                    Eyes
                                </a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#Perfume" role="tab" aria-controls="Perfume" aria-selected="false">
                                    Perfume
                                </a>
                            </li>
                          
                         
                        </ul>
                    </div>
                </div>
            </div>
            <div class="product_wrapper product_color3">
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="Nailpolish" role="tabpanel">
                        <div class="row product_slick_row4">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->category): ?>
                                <?php if($product->category->slug =='Nails'): ?>
                                    <div class="col-lg-3">
                                    
                                        <div class="single_product">

                                                <div class="product_thumb">
                                                    <a class="primary_img" href="<?php echo e(route('products.detail', $product->slug)); ?>"><img src="<?php echo e(asset($product->image_path)); ?>" alt=""></a>
                                                    
                                                
                                                    <div class="action_links">
                                                        <ul>
                                                        
                                                            <li ><a href="#" class="view-quickview" data-product_id="<?php echo e($product->id); ?>" id="quickviewproduct" data-toggle="modal" data-target="#productquickview" title="Quick View"><i class="ion-eye"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="product_content">
                                                    <div class="product_name">
                                                        <h4><a href="<?php echo e(route('products.detail', $product->slug)); ?>"><?php echo e($product->title); ?></a></h4>
                                                    </div>
                                                    
                                                    <div class="price-container">
                                                        <div class="price_box">
                                                            <span class="current_price">Rs <?php echo e($product->price); ?></span>
                                                        
                                                        </div>
                                                    
                                                    </div>

                                                </div>
                                        
                                        </div>
                                    
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Eyes" role="tabpanel">
                        <div class="row product_slick_row4">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->category->slug =='eye-liner'): ?>
                                <div class="col-lg-3">
                                    
                                    <div class="single_product">

                                            <div class="product_thumb">
                                                <a class="primary_img" href="<?php echo e(route('products.detail', $product->slug)); ?>"><img src="<?php echo e(asset($product->image_path)); ?>" alt=""></a>
                                                <a class="secondary_img" href="<?php echo e(route('products.detail', $product->slug)); ?>"><img src="<?php echo e(asset($product->banner_path)); ?>" alt=""></a>
                                               
                                                <div class="action_links">
                                                    <ul>
                                                    
                                                        <li ><a href="#" class="view-quickview" data-product_id="<?php echo e($product->id); ?>" id="quickviewproduct" data-toggle="modal" data-target="#productquickview" title="Quick View"><i class="ion-eye"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="product_content">
                                                <div class="product_name">
                                                    <h4><a href="<?php echo e(route('products.detail', $product->slug)); ?>"><?php echo e($product->title); ?></a></h4>
                                                </div>
                                                
                                                <div class="price-container">
                                                    <div class="price_box">
                                                        <span class="current_price">Rs <?php echo e($product->price); ?></span>
                                                    
                                                    </div>
                                                
                                                </div>

                                            </div>
                                    
                                    </div>
                                
                                </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div> 
                    <div class="tab-pane fade" id="Perfume" role="tabpanel">
                        <div class="row product_slick_row4">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->category->slug =='perfume'): ?>
                                <div class="col-lg-3">
                                
                                    <div class="single_product">

                                            <div class="product_thumb">
                                                <a class="primary_img" href="<?php echo e(route('products.detail', $product->slug)); ?>"><img src="<?php echo e(asset($product->image_path)); ?>" alt=""></a>
                                                <a class="secondary_img" href="<?php echo e(route('products.detail', $product->slug)); ?>"><img src="<?php echo e(asset($product->banner_path)); ?>" alt=""></a>
                                               
                                                <div class="action_links">
                                                    <ul>
                                                       
                                                        <li ><a href="#" class="view-quickview" data-product_id="<?php echo e($product->id); ?>" id="quickviewproduct" data-toggle="modal" data-target="#productquickview" title="Quick View"><i class="ion-eye"></i></a></li>
                                                        
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="product_content">
                                                <div class="product_name">
                                                    <h4><a href="<?php echo e(route('products.detail', $product->slug)); ?>"><?php echo e($product->title); ?></a></h4>
                                                </div>
                                                
                                                <div class="price-container">
                                                    <div class="price_box">
                                                        <span class="current_price">Rs <?php echo e($product->price); ?></span>
                                                      
                                                    </div>
                                                   
                                                </div>

                                            </div>
                                    
                                    </div>
                                
                                </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
    </section>
    <!--new product area end-->

      <!--banner fullwidth area start-->
      <div class="banner_fullwidth">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-12">
                    <div class="banner_thumb">
                        <a href="https://demo.hasthemes.com/alista-preview/alista/shop.html"><img src="https://demo.hasthemes.com/alista-preview/alista/assets/img/bg/banner21.jpg" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--banner fullwidth area end-->

     

    <!--new product area start-->
    <section class="product_area product_three mb-40">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title title_style3">
                        <h3> Best Sellers</h3>
                    </div>
                </div>
            </div>
            <div class="product_wrapper product_color3">
                <div class="row product_slick_column4">
                    <?php $__currentLoopData = $bestsellerproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                           
                            <div class="col-lg-3">
                                <div class="single_product">

                                    <div class="product_thumb">
                                        <a class="primary_img" href="<?php echo e(route('products.detail', $product->slug)); ?>"><img src="<?php echo e(asset($product->image_path)); ?>" alt=""></a>
                                       
                                       
                                        <div class="action_links">
                                            <ul>
                                                <li ><a href="#" class="view-quickview" data-product_id="<?php echo e($product->id); ?>" id="quickviewproduct" data-toggle="modal" data-target="#productquickview" title="Quick View"><i class="ion-eye"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product_content">
                                        <div class="product_name">
                                            <h4><a href="<?php echo e(route('products.detail', $product->slug)); ?>"><?php echo e($product->title); ?></a></h4>
                                        </div>
                                        
                                        <div class="price-container">
                                            <div class="price_box">
                                                <span class="current_price">Rs <?php echo e($product->price); ?></span>
                                              
                                            </div>
                                           
                                        </div>

                                    </div>
                            
                                </div>
                            </div>
                            
                       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </div>
            </div>
        </div>
    </section>
    <!--new product area end-->

        <!--services img area-->
    <div class="container"> 
        <div class="row">
            <div class="col-12">
                <div class="section_title title_style3">
                    <h3> Our Services</h3>
                </div>
            </div>
        </div>
        <div class="services_gallery mt-60">
            <div class="container">  
                <div class="row">
                    <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="single_services">
                                <div class="services_thumb">
                                    <a href="<?php echo e(route('trainings.detail', $training->slug)); ?>"> <img src="<?php echo e(asset($training->image_path)); ?>" alt="">
                                </div>
                                <div class="services_content">
                                <h3><?php echo e($training->title); ?></h3>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>     
        </div>
    </div>
    <!--services img end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/frontend/home.blade.php ENDPATH**/ ?>