<?php $__env->startSection('content'); ?>

  
  <!--breadcrumbs area start-->
    
    <div class="breadcrumbs_area">
        <div class="container">   
            <div class="row">
               
                    <div class="col-12">
                        <div class="breadcrumb_content">
                            <h3>Products</h3>
                            <ul>
                                <li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
                                <li>Search</li>
                            </ul>
                        </div>
                    </div>
            </div>
        </div>         
    </div>

   
    
<!--breadcrumbs area end-->

    <!--shop  area start-->
    <?php if($product): ?>
        <div class="shop_area shop_reverse">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <!--shop wrapper start-->
                        <!--shop toolbar start-->
                
                    
                        <div class="shop_toolbar_wrapper">
                            <div class="shop_toolbar_btn">

                                <button data-role="grid_3" type="button" class="active btn-grid-3" data-toggle="tooltip" title="3"></button>

                                <button data-role="grid_list" type="button"  class="btn-list" data-toggle="tooltip" title="List"></button>
                            </div>
                            <div class=" niceselect_option">

                                <form class="select_option" action="#">
                                    <select name="orderby" id="short">

                                        <option selected value="1">Sort by average rating</option>
                                        <option  value="2">Sort by popularity</option>
                                        <option value="3">Sort by newness</option>
                                        <option value="4">Sort by price: low to high</option>
                                        <option value="5">Sort by price: high to low</option>
                                        <option value="6">Product Name: Z</option>
                                    </select>
                                </form>


                            </div>
                            <div class="page_amount">
                                <p>Showing 1–9 of 21 results</p>
                            </div>
                        </div>
                        <!--shop toolbar end-->
                        
                        <?php if($product): ?>
                        <div class="row shop_wrapper">
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productsdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-4 col-12 ">
                                    <div class="single_product">

                                        <div class="product_thumb">
                                            <a class="primary_img" href="<?php echo e(route('products.detail', $productsdata->slug)); ?>"><img src="<?php echo e(asset($productsdata->image_path)); ?>" alt=""></a>
                                            <a class="secondary_img" href="<?php echo e(route('products.detail', $productsdata->slug)); ?>"><img src="<?php echo e(asset($productsdata->banner_path)); ?>" alt=""></a>
                                           
                                            
                                        </div>
                                        <div class="product_content">
                                            <div class="product_name">
                                                <h4><a href="<?php echo e(route('products.detail', $productsdata->slug)); ?>"><?php echo e($productsdata->title); ?></a></h4>
                                            </div>
                                            
                                            <div class="price-container">
                                                <div class="price_box">
                                                    <span class="current_price">Rs <?php echo e($productsdata->price); ?></span>
                                                  
                                                </div>
                                               
                                            </div>

                                        </div>
                                
                                     </div>  
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>
                        <?php endif; ?>

                
                        <!--shop toolbar end-->
                        <!--shop wrapper end-->
                    </div>
                </div>
            </div>
        </div>
    
    <?php endif; ?>   
    <!--shop  area end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/frontend/product/productsearch.blade.php ENDPATH**/ ?>