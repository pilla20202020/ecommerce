
<?php $__env->startSection('content'); ?>




<!--training body area start-->
<div class="main_blog_area blog_details">
    <div class="container">
        <div class="row">
            <?php if($trainings): ?>
                <div class="col-lg-9 col-md-12">
                    <!--blog grid area start-->
                    <div class="blog_details_wrapper">
                       
                        <div class="single_blog">
                            <div class="blog_title">
                                <h2><a href="#"><?php echo e($trainings->title); ?></a></h2>
                                <div class="blog_post">
                                    <ul>
                                        <li class="post_author">Trainer : <?php echo e($trainings->trainer); ?></li>
                                        <li class="post_date"><?php echo e($trainings->training_date->format('d/m/Y')); ?></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="blog_thumb">
                            <a href="#"><img src="<?php echo e(asset($trainings->image_path)); ?>" alt=""></a>
                        </div>
                            <div class="blog_content">
                                <div class="post_content">
                                    <p><?php echo $trainings->content; ?></p>
                                    
                                </div>

                            </div>
                        </div>
                        
                        
                    </div>
                    <!--blog grid area start-->
                </div>
                <div class="col-lg-3 col-md-12">
                    <div class="blog_sidebar_widget">
                        <div class="widget_list widget_categories">
                            <h2>Our Services</h2>
                           
                            <ul>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php echo e($service->title); ?>

                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </ul>
                        </div>
                    
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<!--training section area end-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/frontend/service/detail.blade.php ENDPATH**/ ?>