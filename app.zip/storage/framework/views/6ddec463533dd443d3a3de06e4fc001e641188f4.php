<?php $__env->startSection('content'); ?>

  
  <!--breadcrumbs area start-->
    <?php if($category): ?>
    <div class="breadcrumbs_area">
        <div class="container">   
            <div class="row">
               
                    <div class="col-12">
                        <div class="breadcrumb_content">
                            <h3>Products</h3>
                            <ul>
                                <li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
                                <li><a href="<?php echo e(route('products',$category->slug)); ?>"><?php echo e($category->title); ?></a></li>
                            </ul>
                        </div>
                    </div>
            </div>
        </div>         
    </div>
    <?php endif; ?>
   
    
<!--breadcrumbs area end-->

    <!--shop  area start-->
    <?php if($category): ?>
        <div class="shop_area shop_reverse">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <!--shop wrapper start-->
                        <!--shop toolbar start-->
                        <div class="shop_title">
                            <h1><?php echo e($category->title); ?></h1>
                        </div>
                    
                        <div class="shop_toolbar_wrapper">
                            <div class="shop_toolbar_btn">

                                <button data-role="grid_3" type="button" class="active btn-grid-3" data-toggle="tooltip" title="3"></button>

                                <button data-role="grid_list" type="button"  class="btn-list" data-toggle="tooltip" title="List"></button>
                            </div>
                            <div>

                                
                                        
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown">
                                                Sort by 
                                            </button>
                                            <div class="dropdown-menu">
                                              <a class="dropdown-item" href="<?php echo e(route('products',$category->slug)); ?>?option=name">Name</a>
                                              <a class="dropdown-item" href="<?php echo e(route('products',$category->slug)); ?>?option=price-low-to-high">Price: Low to High</a>
                                              <a class="dropdown-item" href="<?php echo e(route('products',$category->slug)); ?>?option=price-high-to-low">Price: High to low</a>
                                            </div>
                                        </div>


                            </div>
                            <div class="page_amount">
                                <p>Showing 1–9 of <?php echo e($product->count()); ?></p>
                            </div>
                        </div>
                        <!--shop toolbar end-->
                        
                        <?php if($product): ?>
                        <div class="row shop_wrapper">
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productsdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-4 col-12 ">
                                    <div class="single_product">

                                        <div class="product_thumb">
                                            <a class="primary_img" href="<?php echo e(route('products.detail', $productsdata->slug)); ?>"><img src="<?php echo e(asset($productsdata->image_path)); ?>" alt=""></a>
                                            
                                           
                                            
                                        </div>
                                        <div class="product_content">
                                            <div class="product_name">
                                                <h4><a href="<?php echo e(route('products.detail', $productsdata->slug)); ?>"><?php echo e($productsdata->title); ?></a></h4>
                                            </div>
                                            
                                            <div class="price-container">
                                                <div class="price_box">
                                                    <span class="current_price">Rs <?php echo e($productsdata->price); ?></span>
                                                  
                                                </div>
                                               
                                            </div>

                                        </div>
                                
                                     </div>  
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>
                        <?php endif; ?>

                        <div class="shop_toolbar t_bottom">
                            <div class="pagination">
                                <ul>
                                   <?php echo e($product->links()); ?>

                                </ul>
                            </div>
                        </div>
                        <!--shop toolbar end-->
                        <!--shop wrapper end-->
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>   
    <!--shop  area end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/frontend/product/productcategory.blade.php ENDPATH**/ ?>