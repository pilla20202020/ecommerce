<?php $__env->startSection('title', 'Page'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            
            <?php echo e(Form::open(['route' =>substr(Route::currentRouteName(), 0 , strpos(Route::currentRouteName(), '.')).'.store','class'=>'form form-validate','role'=>'form', 'files'=>true, 'novalidate'])); ?>

            <?php echo $__env->make('backend.page.partials.form', ['header' => 'Create a page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo e(Form::close()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('backend/assets/css/libs/dropify/dropify.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('backend/assets/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/libs/dropify/dropify.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/page/create.blade.php ENDPATH**/ ?>