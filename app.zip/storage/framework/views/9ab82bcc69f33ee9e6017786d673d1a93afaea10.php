<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">
            <div class="row">
                <div class="card">
                    <div class="card-body">
                        <h1 class="text-bold text-center">Welcome To Sonata Website Admin Panel</h1>
                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/dashboard/index.blade.php ENDPATH**/ ?>