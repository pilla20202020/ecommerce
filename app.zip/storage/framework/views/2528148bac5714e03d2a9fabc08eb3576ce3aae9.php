<tr>
    <td><?php echo e(++$key); ?></td>
    <td><?php echo e(Str::limit($page->title, 47)); ?></td>

    <td class="text-center">
        <?php if($page->is_published =='1'): ?>
            <span class="badge" style="background-color: #419645"><?php echo e($page->is_published ? 'Yes' : 'No'); ?></span>
        <?php elseif($page->is_published =='0'): ?>
            <span class="badge" style="background-color: #f44336"><?php echo e($page->is_published ? 'Yes' : 'No'); ?></span>
        <?php endif; ?>
    </td>
    <td class="text-right">
        <a href="<?php echo e(route('page.edit', $page->slug)); ?>" class="btn btn-flat btn-primary btn-xs" title="edit">
            <i class="glyphicon glyphicon-edit"></i>
        </a>
         <a href="<?php echo e(route('page.destroy', $page->id)); ?>">
            <button type="button" data-url="<?php echo e(route('page.destroy', $page->slug)); ?>"
                    class="btn btn-flat btn-danger btn-xs item-delete" title="delete">
                <i class="glyphicon glyphicon-trash"></i>
            </button>
    </td>
</tr>
<?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/page/partials/table.blade.php ENDPATH**/ ?>