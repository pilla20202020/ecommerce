<tr>
    <td><?php echo e(++$key); ?></td>
    <td><img src="<?php echo e(asset($service->thumbnail_path)); ?>" class="img-circle width-1" alt="service_image" width="50" height="50"></td>
    <td><?php echo e(Str::limit($service->title, 47)); ?></td>

    <td class="text-center">
        <?php if($service->is_published =='1'): ?>
            <span class="badge" style="background-color: #419645"><?php echo e($service->is_published ? 'Yes' : 'No'); ?></span>
        <?php elseif($service->is_published =='0'): ?>
            <span class="badge" style="background-color: #f44336"><?php echo e($service->is_published ? 'Yes' : 'No'); ?></span>
        <?php endif; ?>    </td>
    <td class="text-right">
        <a href="<?php echo e(route('service.edit', $service->slug)); ?>" class="btn btn-flat btn-primary btn-xs" title="edit">
            <i class="glyphicon glyphicon-edit"></i>
        </a>
        <a href="<?php echo e(route('service.destroy', $service->id)); ?>">
        <button type="button" 
            class="btn btn-flat btn-danger btn-xs item-delete" title="delete">
            <i class="glyphicon glyphicon-trash"></i>
        </button>
    </td>
</tr>

<?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/service/partials/table.blade.php ENDPATH**/ ?>