<!--header area start-->
<header class="header_area">
    <!--header top area start-->
    <div class="header_top">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="header_top_right">
                        
                        <div class="header_social">
                            <ul>
                                <li><a href="<?php echo e(setting('facebook')); ?>"><i class="ion-social-facebook"></i></a></li>
                                <li><a href="#"><i class="ion-social-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--header top area end -->
    
    <!--header middle area start-->
    <div class="header_middle">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-12">
                    <div class="logo logo_three">
                        <a href="<?php echo e(route('homepage')); ?>"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" width="65%" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-10 col-md-12">
                    <div class="header_middle_right">
                        <div class="header_contact">
                            <div class="contact_static">
                                <a href="tel:<?php echo e(setting('phone')); ?>"><i class="ion-android-call"></i> Call Us: <?php echo e(setting('phone')); ?></a>
                                
                            </div>
                            <div class="contact_static">
                                <a href="mailto:<?php echo e(setting('email')); ?>"><i class="ion-android-mail"></i> <?php echo e(setting('email')); ?></a>
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--header middle area end-->
    
    <!--header bottom start-->
    

<div class="header_bottom sticky-header">
    <div class="container">
        <div class="header_container_right container_position">
            <div class="main_menu menu_three"> 
                <nav>  
                    <ul>
                        <li class="active"><a  href="<?php echo e(route('homepage')); ?>"> Home</a>
                                                        
                        </li>
                        <li class="mega_items"><a href="">Products</a> 
                            <div class="mega_menu">
                                <ul class="mega_menu_inner">
                                 
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('products',$category->slug)); ?>"><?php echo e($category->title); ?></a>
                                            <ul>  
                                                <li>
                                                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                        <?php if($category->id == $subcategory->category->id): ?>
                                                            <a href="<?php echo e(route('all-products',$subcategory->slug)); ?>"><?php echo e($subcategory->title); ?></a>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                </li>                   
                                            </ul>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                   
                                </ul>
                            </div>
                        </li>
                         
                        <li class="mega-items"><a href="<?php echo e(route('services')); ?>"> Our Services</a>
                        
                        </li>
                        <li><a href="<?php echo e(route('about')); ?>"> About Us</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>"> Contact Us</a></li>
                    </ul>  
                </nav> 
            </div>
            <div class="header_block_right">
                <ul>
                    <li class="search_bar"><a href="javascript:void(0)"><i class="ion-ios-search-strong"></i></a> </li>
                </ul>
            </div>
        </div>
    </div>
    <!--header bottom end-->
</div>
</header>
<!--header area end-->
<!--search overlay-->

<div class="dropdown_search dropdown_search_three">
    <div class="search_close_btn">
        <i class="ion-android-close btn-close"></i>
    </div>
    <div class="search_container">
        <form action="<?php echo e(route('search')); ?>">
            <input name="keyword" placeholder="Search here…" type="text">
            <button type="submit"><i class="ion-ios-search-strong"></i></button>
        </form>
    </div>
</div>

<!--search overlay end-->
<?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/frontend/layouts/partials/header.blade.php ENDPATH**/ ?>