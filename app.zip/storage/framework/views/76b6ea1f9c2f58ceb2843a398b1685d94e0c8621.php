<tr>
    <td><?php echo e(++$key); ?></td>
    <td><img src="<?php echo e(asset($training->thumbnail_path)); ?>" class="img-circle width-1" alt="training_image" width="50" height="50"></td>
    <td><?php echo e(Str::limit($training->title, 47)); ?></td>
    <td class="text-center"><?php echo e(($training->training_date)->format('Y-m-d')); ?></td>

    <td class="text-center">
        <?php if($training->is_published =='1'): ?>
            <span class="badge" style="background-color: #419645"><?php echo e($training->is_published ? 'Yes' : 'No'); ?></span>
        <?php elseif($training->is_published =='0'): ?>
            <span class="badge" style="background-color: #f44336"><?php echo e($training->is_published ? 'Yes' : 'No'); ?></span>
        <?php endif; ?>    </td>
    <td class="text-right">
        <a href="<?php echo e(route('training.edit', $training->slug)); ?>" class="btn btn-flat btn-primary btn-xs" title="edit">
            <i class="glyphicon glyphicon-edit"></i>
        </a>
        <a href="<?php echo e(route('training.destroy', $training->id)); ?>">
        <button type="button" 
            class="btn btn-flat btn-danger btn-xs item-delete" title="delete">
            <i class="glyphicon glyphicon-trash"></i>
        </button>
    </td>
</tr>

<?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/training/partials/table.blade.php ENDPATH**/ ?>