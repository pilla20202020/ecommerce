<footer class="footer">
    <div class="menubar-foot-panel">
						<small class="no-linebreak hidden-folded">
							<span class="opacity-75">Copyright &copy; 2021</span> <strong></strong>
						</small>
	</div>
</footer>
<?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/layouts/admin/footer.blade.php ENDPATH**/ ?>