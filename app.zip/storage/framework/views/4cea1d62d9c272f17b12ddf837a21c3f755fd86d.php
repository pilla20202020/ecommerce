<?php $__env->startSection('title', 'Service'); ?>

<?php $__env->startSection('content'); ?>
<section>
        <div class="section-body">
            <form class="form form-validate floating-label" action="<?php echo e(route('service.store')); ?>" method="POST" enctype="multipart/form-data" novalidate>
            <?php echo $__env->make('backend.service.partials.form',['header' => 'Create a service'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('backend/assets/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/libs/dropify/dropify.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/service/create.blade.php ENDPATH**/ ?>