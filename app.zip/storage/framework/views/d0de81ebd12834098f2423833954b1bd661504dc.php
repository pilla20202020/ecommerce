<tr>
    <td><?php echo e(++$key); ?></td>
    <td><img src="<?php echo e(asset($slide->thumbnail_path)); ?>" class="img-circle width-1" alt="slide_image" width="50" height="50"></td>
    <td><?php echo e(Str::limit($slide->title, 47)); ?></td>


   
    <td class="text-right">
        <a href="<?php echo e(route('slider.edit', $slide->id)); ?>" class="btn btn-flat btn-primary btn-xs" title="edit">
            <i class="glyphicon glyphicon-edit"></i>
        </a>
        <a href="<?php echo e(route('slider.destroy', $slide->id)); ?>">
            <button type="button" 
                    class="btn btn-flat btn-danger btn-xs item-delete" title="delete">
                <i class="glyphicon glyphicon-trash"></i>
            </button>
        </a>
    </td>
</tr>

<?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/slider/partials/table.blade.php ENDPATH**/ ?>