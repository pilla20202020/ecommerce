<?php $__env->startSection('title', 'Sub Category'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="section-body">

            <?php echo e(Form::open(['route' =>'subcategory.store','class'=>'form form-validate','role'=>'form', 'files'=>true, 'novalidate'])); ?>

            <?php echo $__env->make('backend.subcategory.partials.form', ['header' => 'Create a SubCategory'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo e(Form::close()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet"href="<?php echo e(asset('backend/assets/css/dropify.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('backend/assets/js/libs/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/libs/jquery-validation/dist/additional-methods.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/libs/dropify/dropify.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demoaccessworld/public_html/projects/sonata/resources/views/backend/subcategory/create.blade.php ENDPATH**/ ?>